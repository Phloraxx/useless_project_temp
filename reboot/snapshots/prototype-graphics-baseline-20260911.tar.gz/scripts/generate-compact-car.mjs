import fs from 'node:fs'
import path from 'node:path'
import * as THREE from 'three'
import { GLTFExporter } from 'three/examples/jsm/exporters/GLTFExporter.js'
import { RoundedBoxGeometry } from 'three/examples/jsm/geometries/RoundedBoxGeometry.js'

class NodeFileReader {
  result = null
  onloadend = null
  async readAsArrayBuffer(blob) {
    this.result = await blob.arrayBuffer()
    queueMicrotask(() => this.onloadend?.())
  }
  async readAsDataURL(blob) {
    const bytes = Buffer.from(await blob.arrayBuffer())
    this.result = `data:${blob.type || 'application/octet-stream'};base64,${bytes.toString('base64')}`
    queueMicrotask(() => this.onloadend?.())
  }
}
globalThis.FileReader = NodeFileReader

const scene = new THREE.Scene()
scene.name = 'AduthaStoppilCompactCarAsset'
const car = new THREE.Group()
car.name = 'CompactCar'
scene.add(car)

const mat = (name, color, roughness=.76, metalness=0) => {
  const m = new THREE.MeshStandardMaterial({ color, roughness, metalness })
  m.name = name
  return m
}
const body = mat('BodyColor', '#5e7f92', .68)
const glass = mat('Glass', '#172c33', .26, .08)
const trim = mat('Trim', '#25292a', .82)
const metal = mat('Metal', '#8a8d86', .40, .50)
const tyre = mat('Tyre', '#16191a', .96)
const lamp = mat('Lamp', '#e9ddb1', .32)
const tail = mat('Tail', '#8d2028', .52)
const amber = mat('Amber', '#cf8b25', .46)

function box(name, size, pos, material, rounded=false) {
  const g = rounded ? new RoundedBoxGeometry(size[0], size[1], size[2], 2, .08) : new THREE.BoxGeometry(...size)
  const mesh = new THREE.Mesh(g, material)
  mesh.name = name
  mesh.position.set(...pos)
  mesh.castShadow = true
  mesh.receiveShadow = true
  car.add(mesh)
  return mesh
}
function cyl(name, radius, depth, pos, material, segments=18) {
  const mesh = new THREE.Mesh(new THREE.CylinderGeometry(radius, radius, depth, segments), material)
  mesh.name = name
  mesh.position.set(...pos)
  mesh.rotation.z = Math.PI / 2
  mesh.castShadow = true
  car.add(mesh)
  return mesh
}

box('LowerBody',[2.00,.72,4.18],[0,.72,0],body,true)
box('Cabin',[1.78,.78,2.25],[0,1.35,.28],body,true)
box('Hood',[1.86,.28,1.02],[0,1.02,-1.60],body,true)
box('FrontWindshield',[1.52,.55,.06],[0,1.48,-.88],glass)
box('RearWindow',[1.48,.50,.06],[0,1.48,1.42],glass)
box('FrontBumper',[1.82,.15,.16],[0,.50,-2.14],trim)
box('RearBumper',[1.82,.15,.16],[0,.50,2.14],trim)
for (const side of [-1,1]) {
  box(`FrontSideWindow_${side}`,[.055,.48,.74],[side*.90,1.48,-.32],glass)
  box(`RearSideWindow_${side}`,[.055,.48,.70],[side*.90,1.48,.72],glass)
  box(`MirrorArm_${side}`,[.22,.04,.04],[side*1.05,1.45,-.78],metal)
  box(`Mirror_${side}`,[.08,.20,.24],[side*1.17,1.43,-.82],trim)
  box(`DoorTrim_${side}`,[.035,.05,1.92],[side*1.015,1.02,.22],trim)
}
for (const x of [-.62,.62]) {
  cyl(`Headlamp_${x}`,.16,.06,[x,.91,-2.10],lamp,20)
  cyl(`TailLamp_${x}`,.14,.06,[x,.88,2.10],tail,18)
}
box('FrontGrille',[.72,.22,.045],[0,.73,-2.18],trim)
box('NumberPlateFront',[.52,.16,.035],[0,.58,-2.19],metal)
box('NumberPlateRear',[.52,.16,.035],[0,.58,2.19],metal)
box('RoofStrip',[1.35,.055,1.42],[0,1.78,.34],metal)

const wheelPos=[[-1.00,-1.36],[1.00,-1.36],[-1.00,1.30],[1.00,1.30]]
wheelPos.forEach(([x,z],i)=>{
  const w=new THREE.Group(); w.name=`CarWheel_${i}`; w.position.set(x,.48,z)
  const t=new THREE.Mesh(new THREE.CylinderGeometry(.38,.38,.26,20),tyre); t.rotation.z=Math.PI/2; t.castShadow=true; w.add(t)
  const h=new THREE.Mesh(new THREE.CylinderGeometry(.18,.18,.28,16),metal); h.rotation.z=Math.PI/2; w.add(h)
  car.add(w)
})

let triangles=0, meshes=0
car.traverse(o=>{if(o.isMesh){meshes++; const g=o.geometry; triangles += g.index ? g.index.count/3 : g.attributes.position.count/3}})
const output=path.resolve('public/models/compact-car.glb')
const exporter=new GLTFExporter()
await new Promise((resolve,reject)=>exporter.parse(scene,r=>{fs.writeFileSync(output,Buffer.from(r));resolve()},reject,{binary:true,onlyVisible:true,copyright:'Adutha Stoppil original fictional compact car, 2026'}))
console.log(JSON.stringify({output,bytes:fs.statSync(output).size,meshes,triangles:Math.round(triangles)},null,2))