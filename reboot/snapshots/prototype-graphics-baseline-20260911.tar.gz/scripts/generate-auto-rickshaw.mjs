import fs from 'node:fs'
import path from 'node:path'
import * as THREE from 'three'
import { GLTFExporter } from 'three/examples/jsm/exporters/GLTFExporter.js'
import { RoundedBoxGeometry } from 'three/examples/jsm/geometries/RoundedBoxGeometry.js'

class NodeFileReader {
  result = null
  onloadend = null
  async readAsArrayBuffer(blob) {
    this.result = await blob.arrayBuffer()
    queueMicrotask(() => this.onloadend?.())
  }
  async readAsDataURL(blob) {
    const bytes = Buffer.from(await blob.arrayBuffer())
    this.result = `data:${blob.type || 'application/octet-stream'};base64,${bytes.toString('base64')}`
    queueMicrotask(() => this.onloadend?.())
  }
}
globalThis.FileReader = NodeFileReader

const scene = new THREE.Scene()
scene.name = 'AduthaStoppilAutoAsset'
const auto = new THREE.Group()
auto.name = 'AutoRickshaw'
scene.add(auto)

const mat = (name, color, roughness=.8, metalness=0) => {
  const m = new THREE.MeshStandardMaterial({ color, roughness, metalness })
  m.name = name
  return m
}
const charcoal = mat('AutoBody', '#202322', .9)
const mustard = mat('Canopy', '#d5a42a', .78)
const glass = mat('Glass', '#20363a', .3, .05)
const rubber = mat('Rubber', '#151719', .96)
const metal = mat('Metal', '#8b8d85', .45, .5)
const lamp = mat('Lamp', '#efe1a8', .3)
const red = mat('Tail', '#8c2630', .5)
const seat = mat('Seat', '#4f3a2d', .9)

function box(name, size, pos, material, parent=auto, rot=[0,0,0]) {
  const m = new THREE.Mesh(new THREE.BoxGeometry(...size), material)
  m.name=name; m.position.set(...pos); m.rotation.set(...rot)
  m.castShadow=true; m.receiveShadow=true; parent.add(m); return m
}
function rounded(name,size,pos,material,r=.08,parent=auto){
  const m=new THREE.Mesh(new RoundedBoxGeometry(size[0],size[1],size[2],2,r),material)
  m.name=name; m.position.set(...pos); m.castShadow=true; m.receiveShadow=true; parent.add(m); return m
}
function cyl(name,radius,depth,pos,rot,material,parent=auto,segments=16){
  const m=new THREE.Mesh(new THREE.CylinderGeometry(radius,radius,depth,segments),material)
  m.name=name; m.position.set(...pos); m.rotation.set(...rot); m.castShadow=true; parent.add(m); return m
}

rounded('LowerBody',[1.52,.72,2.35],[0,.65,.05],charcoal,.10)
rounded('Nose',[1.40,.72,.72],[0,.84,-1.18],charcoal,.13)
box('Floor',[1.42,.10,1.62],[0,.42,.26],charcoal)
box('RearPanel',[1.48,1.20,.10],[0,1.28,1.18],charcoal)
box('Seat',[1.12,.36,.36],[0,.88,.72],seat)
box('SeatBack',[1.12,.72,.18],[0,1.18,.86],seat,auto,[-.08,0,0])

box('Windshield',[1.22,.76,.07],[0,1.63,-.87],glass,auto,[.15,0,0])
box('WindshieldTop',[1.42,.08,.10],[0,2.01,-.80],metal)
for(const x of [-.67,.67]) box(`FrontPillar_${x}`,[.08,.92,.08],[x,1.58,-.76],metal,auto,[.14,0,0])
box('Dashboard',[1.18,.18,.40],[0,1.18,-.73],charcoal,auto,[-.08,0,0])
box('CanopyTop',[1.62,.12,2.25],[0,2.10,.18],mustard)
box('CanopyFront',[1.55,.16,.16],[0,2.02,-.91],mustard)
box('CanopyRear',[1.55,.22,.12],[0,1.90,1.16],mustard)
for(const side of [-1,1]) {
  box(`RoofRail_${side}`,[.06,.80,1.86],[side*.73,1.65,.20],metal)
  box(`SideLower_${side}`,[.08,.68,1.35],[side*.77,.73,.23],charcoal)
  box(`RearArch_${side}`,[.07,.72,.08],[side*.73,1.58,1.08],metal)
}
box('RearWindow',[1.18,.66,.06],[0,1.55,1.235],glass)
box('RearLowerBand',[1.42,.24,.08],[0,.80,1.245],mustard)
box('FrontBumper',[1.25,.12,.18],[0,.36,-1.52],metal)
box('RearBumper',[1.28,.12,.16],[0,.38,1.34],metal)
box('NumberPlate',[.48,.16,.04],[0,.61,-1.61],mustard)

cyl('Headlamp',.16,.07,[0,.92,-1.58],[Math.PI/2,0,0],lamp,auto,20)
for(const x of [-.48,.48]) cyl(`Indicator_${x}`,.07,.06,[x,.88,-1.56],[Math.PI/2,0,0],mustard,auto,14)
for(const x of [-.45,.45]) cyl(`Tail_${x}`,.08,.06,[x,.78,1.34],[Math.PI/2,0,0],red,auto,14)

const wheels=[['WheelFront',0,-1.22],['WheelRearL',-.76,.73],['WheelRearR',.76,.73]]
for(const [name,x,z] of wheels){
  const g=new THREE.Group(); g.name=name; g.position.set(x,.35,z)
  cyl(`${name}_Tyre`,.34,.22,[0,0,0],[0,0,Math.PI/2],rubber,g,18)
  cyl(`${name}_Hub`,.15,.24,[0,0,0],[0,0,Math.PI/2],metal,g,14)
  auto.add(g)
}

box('MirrorArmL',[.34,.04,.04],[-.88,1.62,-.67],metal,auto,[0,0,.12])
box('MirrorArmR',[.34,.04,.04],[.88,1.62,-.67],metal,auto,[0,0,-.12])
box('MirrorL',[.07,.23,.18],[-1.04,1.60,-.67],charcoal)
box('MirrorR',[.07,.23,.18],[1.04,1.60,-.67],charcoal)

let triangles=0, meshes=0
auto.traverse(o=>{ if(!o.isMesh)return; meshes++; const g=o.geometry; triangles+=g.index?g.index.count/3:g.attributes.position.count/3 })
const output=path.resolve('public/models/auto-rickshaw.glb')
fs.mkdirSync(path.dirname(output),{recursive:true})
const exporter=new GLTFExporter()
await new Promise((resolve,reject)=>exporter.parse(scene,result=>{fs.writeFileSync(output,Buffer.from(result));resolve()},reject,{binary:true,onlyVisible:true,copyright:'Adutha Stoppil original fictional auto-rickshaw, 2026'}))
console.log(JSON.stringify({output,bytes:fs.statSync(output).size,meshes,triangles:Math.round(triangles)},null,2))
