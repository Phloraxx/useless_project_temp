import fs from 'node:fs'
import path from 'node:path'
import * as THREE from 'three'
import { GLTFExporter } from 'three/examples/jsm/exporters/GLTFExporter.js'
import { RoundedBoxGeometry } from 'three/examples/jsm/geometries/RoundedBoxGeometry.js'

class NodeFileReader {
  result = null
  onloadend = null
  async readAsArrayBuffer(blob) {
    this.result = await blob.arrayBuffer()
    queueMicrotask(() => this.onloadend?.())
  }
  async readAsDataURL(blob) {
    const bytes = Buffer.from(await blob.arrayBuffer())
    this.result = `data:${blob.type || 'application/octet-stream'};base64,${bytes.toString('base64')}`
    queueMicrotask(() => this.onloadend?.())
  }
}
globalThis.FileReader = NodeFileReader

const scene = new THREE.Scene()
scene.name = 'AduthaStoppilHeroBusAsset'
const bus = new THREE.Group()
bus.name = 'HeroBus'
scene.add(bus)

const material = (name, color, roughness = 0.78, metalness = 0) => {
  const m = new THREE.MeshStandardMaterial({ color, roughness, metalness })
  m.name = name
  return m
}
const red = material('BodyRed', '#9f242a', 0.7)
const cream = material('BodyCream', '#dfd0a8', 0.82)
const dark = material('WindowGlass', '#162b31', 0.28, 0.08)
const rubber = material('Rubber', '#171a1b', 0.95)
const metal = material('TrimMetal', '#8a8d87', 0.42, 0.55)
const amber = material('IndicatorAmber', '#d79323', 0.45)
const lamp = material('Headlamp', '#eee1b0', 0.28)
const tail = material('TailLamp', '#891c24', 0.5)
const grille = material('Grille', '#242829', 0.75, 0.08)

function addBox(name, size, pos, mat, parent = bus, rot = [0, 0, 0]) {
  const mesh = new THREE.Mesh(new THREE.BoxGeometry(...size), mat)
  mesh.name = name
  mesh.position.set(...pos)
  mesh.rotation.set(...rot)
  mesh.castShadow = true
  mesh.receiveShadow = true
  parent.add(mesh)
  return mesh
}


function addRoundedBox(name, size, pos, mat, radius = 0.10, segments = 2, parent = bus) {
  const mesh = new THREE.Mesh(new RoundedBoxGeometry(size[0], size[1], size[2], segments, radius), mat)
  mesh.name = name
  mesh.position.set(...pos)
  mesh.castShadow = true
  mesh.receiveShadow = true
  parent.add(mesh)
  return mesh
}

function addCylinder(name, radius, depth, pos, rot, mat, parent = bus, segments = 18) {
  const mesh = new THREE.Mesh(new THREE.CylinderGeometry(radius, radius, depth, segments), mat)
  mesh.name = name
  mesh.position.set(...pos)
  mesh.rotation.set(...rot)
  mesh.castShadow = true
  parent.add(mesh)
  return mesh
}

const W = 3.16
const L = 7.34
addRoundedBox('LowerBody', [W, 1.52, L], [0, 1.02, 0], red, 0.12, 2)
addRoundedBox('UpperBody', [3.04, 1.42, 6.98], [0, 2.42, 0.05], cream, 0.10, 2)
addRoundedBox('Roof', [3.12, 0.18, 6.92], [0, 3.18, 0.08], cream, 0.07, 2)
addBox('FrontLowerCap', [3.12, 1.08, 0.34], [0, 1.18, -3.57], red)
addBox('RearLowerCap', [3.12, 1.08, 0.34], [0, 1.18, 3.57], red)
addBox('FrontCreamBand', [3.04, 0.47, 0.20], [0, 1.93, -3.61], cream)
addBox('RearCreamBand', [3.04, 0.47, 0.20], [0, 1.93, 3.61], cream)

addBox('WindshieldLeft', [1.27, 0.82, 0.07], [-0.72, 2.53, -3.59], dark)
addBox('WindshieldRight', [1.27, 0.82, 0.07], [0.72, 2.53, -3.59], dark)
addBox('WindshieldDivider', [0.08, 0.88, 0.08], [0, 2.53, -3.64], metal)
addBox('FrontDestinationBoard', [2.14, 0.34, 0.06], [0, 3.00, -3.66], dark)
addBox('FrontVisor', [2.65, 0.10, 0.38], [0, 3.20, -3.57], red, bus, [-0.12, 0, 0])
addBox('RearWindow', [2.34, 0.66, 0.07], [0, 2.53, 3.59], dark)
addBox('RearWindowDivider', [0.07, 0.70, 0.08], [0, 2.53, 3.64], metal)
addBox('RearDestinationBoard', [1.68, 0.28, 0.06], [0, 3.00, 3.66], dark)

for (const side of [-1, 1]) {
  for (let i = 0; i < 5; i++) {
    const z = -2.32 + i * 1.16
    addBox(`SideWindow_${side}_${i}`, [0.07, 0.71, 0.88], [side * 1.54, 2.54, z], dark)
  }
  addBox(`SideBelt_${side}`, [0.07, 0.12, 6.72], [side * 1.58, 1.80, 0.08], red)
  addBox(`LowerRubRail_${side}`, [0.09, 0.12, 6.58], [side * 1.60, 0.63, 0.10], grille)
}

addBox('PassengerDoor', [0.07, 1.75, 1.08], [1.60, 1.47, -2.34], dark)
addBox('PassengerDoorRail', [0.09, 1.82, 0.06], [1.63, 1.48, -1.79], metal)
addBox('SideRouteBoard', [0.06, 0.30, 1.82], [-1.59, 2.97, -0.28], dark)
addBox('FrontGrille', [1.78, 0.47, 0.08], [0, 1.22, -3.77], grille)
for (let i = -2; i <= 2; i++) addBox(`GrilleSlat_${i}`, [0.08, 0.40, 0.05], [i * 0.31, 1.22, -3.83], metal)
addBox('FrontBumper', [2.90, 0.18, 0.22], [0, 0.46, -3.76], metal)
addBox('RearBumper', [2.90, 0.18, 0.22], [0, 0.46, 3.76], metal)
addBox('RearNumberPlate', [0.72, 0.23, 0.04], [0, 0.82, 3.83], cream)
addBox('RearVentLeft', [0.52, 0.22, 0.05], [-0.55, 1.68, 3.78], grille)
addBox('RearVentRight', [0.52, 0.22, 0.05], [0.55, 1.68, 3.78], grille)
addBox('NumberPlate', [0.72, 0.23, 0.04], [0, 0.82, -3.83], cream)

for (const x of [-0.94, 0.94]) {
  addCylinder(`Headlamp_${x}`, 0.24, 0.08, [x, 1.31, -3.83], [Math.PI / 2, 0, 0], lamp, bus, 24)
  addCylinder(`Indicator_${x}`, 0.11, 0.07, [x + Math.sign(x) * 0.34, 1.31, -3.82], [Math.PI / 2, 0, 0], amber, bus, 18)
  addCylinder(`TailLamp_${x}`, 0.17, 0.07, [x, 1.24, 3.82], [Math.PI / 2, 0, 0], tail, bus, 18)
}

for (const side of [-1, 1]) {
  addBox(`MirrorArm_${side}`, [0.48, 0.05, 0.05], [side * 1.78, 2.66, -3.22], metal, bus, [0, 0, side * 0.20])
  addBox(`Mirror_${side}`, [0.10, 0.38, 0.28], [side * 2.02, 2.61, -3.20], grille)
}

const wheelPositions = [
  ['Wheel_FL', -1.62, -2.28], ['Wheel_FR', 1.62, -2.28],
  ['Wheel_RL', -1.62, 2.20], ['Wheel_RR', 1.62, 2.20],
]
for (const [name, x, z] of wheelPositions) {
  const wheel = new THREE.Group()
  wheel.name = name
  wheel.position.set(x, 0.55, z)
  addCylinder(`${name}_Tyre`, 0.57, 0.35, [0, 0, 0], [0, 0, Math.PI / 2], rubber, wheel, 24)
  addCylinder(`${name}_Hub`, 0.27, 0.38, [0, 0, 0], [0, 0, Math.PI / 2], metal, wheel, 18)
  bus.add(wheel)
}
addBox('RoofVent', [1.05, 0.12, 0.72], [0, 3.34, 0.62], grille)
addBox('FrontRoofMarker', [2.20, 0.06, 0.10], [0, 3.29, -3.28], amber)

bus.traverse((obj) => {
  if (obj.isMesh) {
    obj.geometry.computeVertexNormals()
  }
})

let triangles = 0
let meshes = 0
bus.traverse((obj) => {
  if (!obj.isMesh) return
  meshes++
  const g = obj.geometry
  triangles += g.index ? g.index.count / 3 : g.attributes.position.count / 3
})

const output = path.resolve('public/models/hero-bus.glb')
const exporter = new GLTFExporter()
await new Promise((resolve, reject) => {
  exporter.parse(scene, (result) => {
    fs.writeFileSync(output, Buffer.from(result))
    resolve()
  }, reject, {
    binary: true,
    onlyVisible: true,
    trs: false,
    copyright: 'Adutha Stoppil original fictional hero bus, 2026',
  })
})

console.log(JSON.stringify({ output, bytes: fs.statSync(output).size, meshes, triangles: Math.round(triangles) }, null, 2))
