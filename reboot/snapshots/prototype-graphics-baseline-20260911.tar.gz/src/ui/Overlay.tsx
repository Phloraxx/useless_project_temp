import { useEffect, useRef, useState } from 'react'
import { useGameStore, type HornVerdict, type StopVerdict } from '../state/gameStore'

const stopVerdicts: Record<StopVerdict, { kicker: string; title: string; body: string }> = {
  too_early: { kicker: 'പരിശീലനം ആവശ്യമാണ്', title: 'സ്റ്റോപ്പിനു മുമ്പേ നിർത്തിയോ?', body: 'യാത്രക്കാരന് നടക്കാൻ അവസരം തന്നില്ല.' },
  too_precise: { kicker: 'പരിശീലനം ആവശ്യമാണ്', title: 'വളരെ കൃത്യമാണ്.', body: 'അത് മാറ്റണം.' },
  acceptable: { kicker: 'ശരാശരി', title: 'ഇപ്പോൾ ശരിയായി.', body: 'യാത്രക്കാരുടെ ആരോഗ്യത്തിന് ചെറിയൊരു സംഭാവന.' },
  ideal: { kicker: 'മികച്ച പ്രകടനം', title: 'ഇതാണ് ദൂരദർശനം.', body: 'Passenger Cardio Contribution™ മികച്ച നിലയിൽ.' },
  too_far: { kicker: 'അത്രയും വേണ്ട', title: 'അടുത്ത സ്റ്റോപ്പ് ആക്കണ്ട.', body: 'ശാസ്ത്രീയ അസൗകര്യത്തിന്റെ പരിധി കടന്നു.' },
}

const hornVerdicts: Record<HornVerdict, { kicker: string; title: string; body: string }> = {
  horn_low: { kicker: 'ആശയവിനിമയം അപര്യാപ്തം', title: 'ഹോൺ ഉണ്ടല്ലോ.', body: 'ബ്രേക്ക് ഉപയോഗിക്കുന്നതിന് മുമ്പ് സംസാരിക്കാൻ ശ്രമിക്കുക.' },
  horn_good: { kicker: 'മികച്ച പ്രകടനം', title: 'ആശയവിനിമയം വിജയകരം.', body: 'ബ്രേക്ക് ഉപയോഗിക്കാതെ പ്രശ്നം പരിഹരിക്കാനുള്ള സ്വാഭാവിക കഴിവ് കണ്ടെത്തി.' },
  horn_spam: { kicker: 'അമിത ആശയവിനിമയം', title: 'അവർ കേട്ടു.', body: 'അടുത്ത ജില്ലയും കേട്ടു. അല്പം നിയന്ത്രണം ആവശ്യമാണ്.' },
}

function hornSound() {
  const AudioCtx = window.AudioContext || (window as typeof window & { webkitAudioContext: typeof AudioContext }).webkitAudioContext
  if (!AudioCtx) return
  const ctx = new AudioCtx(); const gain = ctx.createGain(); const a = ctx.createOscillator(); const b = ctx.createOscillator()
  a.type = 'square'; b.type = 'sawtooth'; a.frequency.value = 185; b.frequency.value = 148
  gain.gain.setValueAtTime(0.0001, ctx.currentTime); gain.gain.exponentialRampToValueAtTime(0.11, ctx.currentTime + 0.015); gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.25)
  a.connect(gain); b.connect(gain); gain.connect(ctx.destination); a.start(); b.start(); a.stop(ctx.currentTime + 0.27); b.stop(ctx.currentTime + 0.27)
  setTimeout(() => ctx.close(), 400)
}

function ControlButton({ label, control }: { label: string; control: 'accelerate' | 'brake' | 'left' | 'right' }) {
  const setControl = useGameStore((s) => s.setControl)
  return <button className={`touch-btn touch-${control}`} onPointerDown={(e) => { e.preventDefault(); setControl(control, true) }} onPointerUp={() => setControl(control, false)} onPointerCancel={() => setControl(control, false)} onPointerLeave={() => setControl(control, false)}>{label}</button>
}

function TouchControls({ honk }: { honk: () => void }) {
  return <div className="touch-controls"><div className="touch-steer"><ControlButton label="←" control="left" /><ControlButton label="→" control="right" /></div><button className="touch-btn horn" onPointerDown={(e) => { e.preventDefault(); honk() }}>ഹോൺ</button><div className="touch-pedals"><ControlButton label="↑" control="accelerate" /><ControlButton label="↓" control="brake" /></div></div>
}

export function Overlay() {
  const test = useGameStore((s) => s.test); const phase = useGameStore((s) => s.phase); const verdict = useGameStore((s) => s.verdict)
  const offset = useGameStore((s) => s.stopOffset); const finalOffset = useGameStore((s) => s.finalStopOffset); const cardio = useGameStore((s) => s.cardioMeters); const speed = useGameStore((s) => s.speed)
  const hornCount = useGameStore((s) => s.hornCount); const hornScore = useGameStore((s) => s.hornScore); const brakePresses = useGameStore((s) => s.brakePresses)
  const passengerStage = useGameStore((s) => s.passengerStage); const passengerScan = useGameStore((s) => s.passengerScan)
  const finalStage = useGameStore((s) => s.finalStage); const finalHornCount = useGameStore((s) => s.finalHornCount)
  const candidateName = useGameStore((s) => s.candidateName); const certificateId = useGameStore((s) => s.certificateId)
  const setCandidateName = useGameStore((s) => s.setCandidateName); const begin = useGameStore((s) => s.begin); const drive = useGameStore((s) => s.drive); const retry = useGameStore((s) => s.retry); const nextTest = useGameStore((s) => s.nextTest)
  const honk = useGameStore((s) => s.honk); const setPassengerStage = useGameStore((s) => s.setPassengerStage); const setPassengerScan = useGameStore((s) => s.setPassengerScan); const finishPassenger = useGameStore((s) => s.finishPassenger); const finishEta = useGameStore((s) => s.finishEta)
  const setFinalStage = useGameStore((s) => s.setFinalStage); const finishFinal = useGameStore((s) => s.finishFinal); const showCertificate = useGameStore((s) => s.showCertificate); const backToResults = useGameStore((s) => s.backToResults)
  const previousHorn = useRef(0); const [etaWrong, setEtaWrong] = useState<string | null>(null); const [endingStep, setEndingStep] = useState(0); const [verifyJoke, setVerifyJoke] = useState(false)

  const activeHorns = test === 'final' ? finalHornCount : hornCount
  useEffect(() => { if (activeHorns > previousHorn.current) hornSound(); previousHorn.current = activeHorns }, [activeHorns])
  useEffect(() => { previousHorn.current = 0 }, [test])
  useEffect(() => { setEtaWrong(null) }, [test, finalStage])

  useEffect(() => {
    if (test !== 'passenger' || phase !== 'driving') return
    let timer: number | undefined; let interval: number | undefined
    if (passengerStage === 'request') timer = window.setTimeout(() => setPassengerStage('scan'), 1500)
    if (passengerStage === 'scan') {
      const started = performance.now()
      interval = window.setInterval(() => {
        const pct = Math.min(100, ((performance.now() - started) / 3400) * 100)
        setPassengerScan(pct)
        if (pct >= 100) { window.clearInterval(interval); setPassengerStage('recommendation') }
      }, 70)
    }
    if (passengerStage === 'recommendation') timer = window.setTimeout(() => setPassengerStage('missed'), 1550)
    if (passengerStage === 'missed') timer = window.setTimeout(() => setPassengerStage('ack'), 1500)
    if (passengerStage === 'ack') timer = window.setTimeout(() => finishPassenger(), 1350)
    return () => { if (timer) window.clearTimeout(timer); if (interval) window.clearInterval(interval) }
  }, [test, phase, passengerStage, setPassengerStage, setPassengerScan, finishPassenger])

  useEffect(() => {
    if (test !== 'final' || phase !== 'driving' || finalStage !== 'passenger') return
    const t = window.setTimeout(() => setFinalStage('eta'), 1900)
    return () => window.clearTimeout(t)
  }, [test, phase, finalStage, setFinalStage])

  useEffect(() => {
    if (test !== 'final' || finalStage !== 'ending') { setEndingStep(0); return }
    const a = window.setTimeout(() => setEndingStep(1), 650)
    const b = window.setTimeout(() => setEndingStep(2), 2050)
    const c = window.setTimeout(() => finishFinal(), 4550)
    return () => { window.clearTimeout(a); window.clearTimeout(b); window.clearTimeout(c) }
  }, [test, finalStage, finishFinal])

  const currentHornScore = hornScore || Math.max(0, Math.min(100, 100 - Math.abs(hornCount - 7) * 12 - brakePresses * 8))
  const testNumber = test === 'stop' ? '01' : test === 'horn' ? '02' : test === 'passenger' ? '03' : test === 'eta' ? '04' : 'FINAL'
  const chooseEta = (choice: string) => choice === 'വരും' ? (setEtaWrong(null), finishEta()) : setEtaWrong(choice)
  const chooseFinalEta = (choice: string) => choice === 'വരും' ? (setEtaWrong(null), setFinalStage('stop')) : setEtaWrong(choice)

  const finalObjective = finalStage === 'approach' ? 'റൗണ്ടിലേക്ക് പ്രവേശിക്കുക' : finalStage === 'traffic' ? (finalHornCount < 2 ? 'ഓട്ടോയുമായി സംസാരിക്കുക' : 'ധാരണയായി. മുന്നോട്ട്.') : finalStage === 'passenger' ? 'യാത്രക്കാരനെ ശ്രദ്ധിക്കുക' : finalStage === 'eta' ? 'ETA തീരുമാനിക്കുക' : finalStage === 'stop' ? 'FINAL STOP കണ്ടെത്തി നിർത്തുക' : 'പരിശോധന അവസാനിക്കുന്നു'

  return <div className="overlay">
    <div className="brand"><span>അടുത്ത സ്റ്റോപ്പിൽ™</span><small>UNOFFICIAL DRIVER APTITUDE SYSTEM</small></div>

    {phase === 'title' && <section className="panel hero-panel"><div className="seal">01</div><p className="eyebrow">കേരളത്തിലെ ഏറ്റവും അനാവശ്യമായ ഡ്രൈവിംഗ് യോഗ്യതാ പരീക്ഷ</p><h1>നിർത്തേണ്ടിടത്ത്<br />നിർത്തുന്നത് എല്ലാവർക്കും പറ്റും.</h1><p className="lede">സ്റ്റോപ്പ് കൃത്യത, യാത്രക്കാരുടെ നടത്ത ദൂരം, ഹോൺ നയതന്ത്രം എന്നിവ ശാസ്ത്രീയമായി അളക്കുന്ന സംവിധാനം.</p><label className="candidate-field"><span>പരീക്ഷാർത്ഥിയുടെ പേര്</span><input value={candidateName} onChange={(e) => setCandidateName(e.target.value)} placeholder="പേര് നൽകുക" maxLength={48} /></label><button className="primary" onClick={begin}>പരീക്ഷ തുടങ്ങാം <span>→</span></button><p className="disclaimer">Parody prototype · യഥാർത്ഥ റോഡിൽ പരീക്ഷിക്കരുത്.</p></section>}

    {phase === 'briefing' && test === 'stop' && <section className="panel briefing-panel"><p className="eyebrow">പരിശോധന 01 / സ്റ്റോപ്പ് കൃത്യത</p><h2>“ശരി. വണ്ടി എടുത്തോളൂ.”</h2><div className="brief-grid"><div><b>W / ↑</b><span>Accelerate</span></div><div><b>S / ↓</b><span>Brake</span></div><div><b>A D</b><span>Steer</span></div><div><b>SPACE</b><span>Horn</span></div></div><p className="hint">മുന്നിലെ സ്റ്റോപ്പിൽ യാത്രക്കാരെ കയറ്റുക. അത്ര മാത്രം.</p><button className="primary" onClick={drive}>വണ്ടി എടുത്തോളൂ <span>→</span></button></section>}
    {phase === 'briefing' && test === 'horn' && <section className="panel briefing-panel"><p className="eyebrow">പരിശോധന 02 / ഹോൺ നയതന്ത്രം</p><h2>“മുന്നിൽ ചെറിയൊരു പ്രശ്നമുണ്ട്.”</h2><p className="lede compact">വഴി തടസ്സപ്പെടുത്തിയിരിക്കുന്ന വാഹനങ്ങളുമായി ഫലപ്രദമായി ആശയവിനിമയം നടത്തുക.</p><div className="brief-grid horn-brief"><div><b>SPACE</b><span>Communicate</span></div><div><b>W / ↑</b><span>Proceed</span></div><div><b>S / ↓</b><span>Suspicious</span></div><div><b>3</b><span>Negotiations</span></div></div><p className="hint">പരീക്ഷകൻ: “സംസാരിച്ച് തീർക്കാവുന്ന പ്രശ്നത്തിന് ബ്രേക്ക് എന്തിന്?”</p><button className="primary" onClick={drive}>ആശയവിനിമയം തുടങ്ങാം <span>→</span></button></section>}
    {phase === 'briefing' && test === 'passenger' && <section className="panel briefing-panel"><p className="eyebrow">പരിശോധന 03 / Passenger Intelligence</p><h2>“ഇനി AI സഹായിക്കും.”</h2><p className="lede compact">യാത്രക്കാരന്റെ ആവശ്യം മനസ്സിലാക്കി ശരിയായ തീരുമാനമെടുക്കുന്ന Smart Passenger Assistance System പരീക്ഷിക്കുക.</p><p className="hint">പരീക്ഷകൻ: “നിങ്ങൾ ഓടിക്കൂ. ബാക്കി system നോക്കും.”</p><button className="primary" onClick={drive}>AI സഹായം ഓൺ ചെയ്യാം <span>→</span></button></section>}
    {phase === 'briefing' && test === 'eta' && <section className="panel briefing-panel"><p className="eyebrow">പരിശോധന 04 / ETA Management</p><h2>“സമയം കുറവാണ്.”</h2><p className="lede compact">8 കിലോമീറ്റർ ബാക്കി. ഔദ്യോഗികമായി എത്തേണ്ട സമയം: 4 മിനിറ്റ്.</p><p className="hint">ശരിയായ ETA യാത്രക്കാരന് നൽകുക.</p><button className="primary" onClick={drive}>കണക്കാക്കാം <span>→</span></button></section>}
    {phase === 'briefing' && test === 'final' && <section className="panel briefing-panel final-brief"><p className="eyebrow">അവസാന പരിശോധന / തൃശ്ശൂർ റൗണ്ട്</p><h2>“ഇനി എല്ലാം ഒരുമിച്ച്.”</h2><p className="lede compact">മഴ. ട്രാഫിക്. യാത്രക്കാരൻ. ETA. അവസാന സ്റ്റോപ്പ്. നിങ്ങൾ പഠിച്ചതെല്ലാം ശാസ്ത്രീയമായി മറക്കാതെ ഉപയോഗിക്കുക.</p><p className="hint">പരീക്ഷകൻ: “പേടിക്കണ്ട. ഞങ്ങൾ നോക്കുന്നുണ്ട്.”</p><button className="primary" onClick={drive}>FINAL പരീക്ഷ തുടങ്ങാം <span>→</span></button></section>}

    {phase === 'driving' && test !== 'eta' && !(test === 'final' && finalStage === 'eta') && <>
      <div className="hud"><div><span>വേഗം</span><strong>{Math.round(speed * 5.4)}</strong><small>km/h</small></div>{test === 'stop' ? <div><span>Passenger Cardio</span><strong>{cardio}</strong><small>m</small></div> : test === 'horn' ? <div><span>ഹോൺ നയതന്ത്രം</span><strong>{hornCount}</strong><small>signals</small></div> : test === 'passenger' ? <div><span>AI Confidence</span><strong>{passengerStage === 'scan' ? Math.round(passengerScan) : passengerStage === 'idle' ? 0 : 100}</strong><small>%</small></div> : <div><span>FINAL</span><strong>{finalHornCount}</strong><small>horn signals</small></div>}</div>
      <div className="objective"><span>പരിശോധന {testNumber}</span><b>{test === 'stop' ? 'സ്റ്റോപ്പിൽ നിർത്തുക' : test === 'horn' ? (hornCount < 1 ? 'ആദ്യ വാഹനവുമായി സംസാരിക്കുക' : hornCount < 3 ? 'സംഭാഷണം തുടരുക' : hornCount < 5 ? 'അവസാന ധാരണയിലെത്തുക' : 'വഴി വ്യക്തമാണ്. മുന്നോട്ട്.') : test === 'passenger' ? (passengerStage === 'idle' ? 'സാധാരണ പോലെ ഓടിക്കുക' : 'AI നിയന്ത്രണം ഏറ്റെടുത്തു') : finalObjective}</b></div>
      {test === 'horn' && hornCount > 0 && <div className="horn-combo">{hornCount >= 5 ? <><b>ആനവണ്ടി മോഡ്</b><span>ആശയവിനിമയം തുടരുന്നു</span></> : <><b>HORN × {hornCount}</b><span>{hornCount === 1 ? 'ശ്രദ്ധിക്കുക.' : hornCount < 3 ? 'ഒന്ന് മാറാമോ?' : 'ഞാൻ വരുന്നുണ്ട്.'}</span></>}</div>}
      {test === 'final' && finalStage === 'traffic' && finalHornCount > 0 && <div className="horn-combo final-combo"><b>FINAL HORN × {finalHornCount}</b><span>{finalHornCount < 2 ? 'ഒന്ന് കൂടി വ്യക്തമായി പറയൂ.' : 'ധാരണയായി.'}</span></div>}
      {test === 'passenger' && passengerStage !== 'idle' && <div className="passenger-sequence">
        {passengerStage === 'request' && <div className="dialogue-strip"><span>യാത്രക്കാരൻ</span><b>“ചേട്ടാ… അടുത്ത സ്റ്റോപ്പിൽ ഇറക്കണേ.”</b></div>}
        {passengerStage === 'scan' && <div className="ai-panel"><span>PASSENGER INTENT ENGINE</span><h3>അഭ്യർത്ഥന വിശകലനം ചെയ്യുന്നു…</h3><div className="scan-list"><i>ശബ്ദം തിരിച്ചറിഞ്ഞു ✓</i><i>യാത്രക്കാരനെ കണ്ടെത്തി ✓</i><i>അടുത്ത സ്റ്റോപ്പ് കണ്ടെത്തി ✓</i><i>ബ്രേക്ക് ലഭ്യമാണ് ✓</i><i>റോഡ് വ്യക്തമാണ് ✓</i></div><div className="progress"><u style={{ width: `${passengerScan}%` }} /></div><strong>{Math.round(passengerScan)}%</strong></div>}
        {passengerStage === 'recommendation' && <div className="ai-panel result"><span>RECOMMENDED ACTION</span><h3>അടുത്ത സ്റ്റോപ്പിന് ശേഷം നിർത്തുക.</h3><small>AI confidence: 99.8%</small></div>}
        {passengerStage === 'missed' && <div className="dialogue-strip"><span>യാത്രക്കാരൻ</span><b>“ചേട്ടാ… സ്റ്റോപ്പ് പോയി.”</b></div>}
        {passengerStage === 'ack' && <div className="dialogue-strip system"><span>System</span><b>“അറിയാം.”</b></div>}
      </div>}
      {test === 'final' && finalStage === 'passenger' && <div className="dialogue-strip final-dialogue"><span>യാത്രക്കാരൻ</span><b>“ചേട്ടാ… അടുത്ത സ്റ്റോപ്പിൽ ഇറക്കണേ.”</b></div>}
      {test === 'final' && finalStage === 'stop' && <div className="final-stop-callout"><span>FINAL STOP</span><b>ഇവിടെ എവിടെയെങ്കിലും നിർത്തുക.</b></div>}
      {test === 'final' && finalStage === 'ending' && <div className="final-ending"><div className="ending-card">{endingStep === 0 && <b>പരിശോധിക്കുന്നു…</b>}{endingStep === 1 && <b>“മ്മ്…”</b>}{endingStep >= 2 && <><b>“വണ്ടി ഒന്ന് പിന്നോട്ട് ഇടാമോ?”</b><span>{finalOffset >= 0 ? '+' : ''}{finalOffset.toFixed(1)} m</span></>}</div></div>}
      {!(test === 'final' && finalStage === 'ending') && <TouchControls honk={honk} />}
    </>}

    {phase === 'driving' && test === 'eta' && <section className="panel eta-panel"><p className="eyebrow">REALITY ENGINE</p><div className="eta-grid"><div><span>Distance</span><b>8.0 km</b></div><div><span>Available time</span><b>4 min</b></div><div><span>Traffic</span><b>Yes</b></div><div><span>Mathematically possible</span><b>No</b></div></div><h2>ETA എന്ത് കാണിക്കണം?</h2><div className="eta-actions"><button onClick={() => chooseEta('4 മിനിറ്റ്')}>4 മിനിറ്റ്</button><button onClick={() => chooseEta('10 മിനിറ്റ്')}>10 മിനിറ്റ്</button><button onClick={() => chooseEta('അറിയില്ല')}>അറിയില്ല</button><button className="varum" onClick={() => chooseEta('വരും')}>വരും</button></div>{etaWrong && <p className="eta-wrong">“{etaWrong}” — അമിത കൃത്യത കണ്ടെത്തി. വീണ്ടും ശ്രമിക്കുക.</p>}</section>}

    {phase === 'driving' && test === 'final' && finalStage === 'eta' && <section className="panel eta-panel final-eta"><p className="eyebrow">FINAL / ETA CHECK</p><div className="eta-grid"><div><span>Distance</span><b>കുറച്ചുണ്ട്</b></div><div><span>Rain</span><b>Yes</b></div><div><span>Traffic</span><b>Obviously</b></div><div><span>Confidence required</span><b>100%</b></div></div><h2>എപ്പോൾ എത്തും?</h2><div className="eta-actions"><button onClick={() => chooseFinalEta('3 മിനിറ്റ്')}>3 മിനിറ്റ്</button><button onClick={() => chooseFinalEta('10 മിനിറ്റ്')}>10 മിനിറ്റ്</button><button onClick={() => chooseFinalEta('അറിയില്ല')}>അറിയില്ല</button><button className="varum" onClick={() => chooseFinalEta('വരും')}>വരും</button></div>{etaWrong && <p className="eta-wrong">“{etaWrong}” — പഴയ പാഠം മറന്നോ?</p>}</section>}

    {phase === 'verdict' && verdict && test === 'stop' && <section className="panel verdict-panel">{(() => { const copy = stopVerdicts[verdict as StopVerdict]; return <><p className="eyebrow">{copy.kicker}</p><div className="measure"><strong>{offset >= 0 ? '+' : ''}{offset.toFixed(1)}</strong><span>m from designated stop</span></div><h2>{copy.title}</h2><p className="verdict-copy">{copy.body}</p>{offset > 0 && <div className="cardio-result"><span>യാത്രക്കാരുടെ സൗജന്യ നടത്തം</span><b>+{Math.round(offset)} m</b></div>}<div className="action-row"><button className="secondary" onClick={retry}>വീണ്ടും <span>↻</span></button><button className="primary" onClick={nextTest}>അടുത്ത പരിശോധന <span>→</span></button></div></> })()}</section>}
    {phase === 'verdict' && verdict && test === 'horn' && <section className="panel verdict-panel">{(() => { const copy = hornVerdicts[verdict as HornVerdict]; return <><p className="eyebrow">{copy.kicker}</p><div className="measure"><strong>{currentHornScore}</strong><span>% horn diplomacy index</span></div><h2>{copy.title}</h2><p className="verdict-copy">{copy.body}</p><div className="metric-pair"><div><span>ഹോൺ സിഗ്നലുകൾ</span><b>{hornCount}</b></div><div><span>അനാവശ്യ ബ്രേക്ക്</span><b>{brakePresses}</b></div></div><div className="action-row"><button className="secondary" onClick={retry}>വീണ്ടും <span>↻</span></button><button className="primary" onClick={nextTest}>അടുത്ത പരിശോധന <span>→</span></button></div></> })()}</section>}
    {phase === 'verdict' && verdict === 'passenger_ai' && test === 'passenger' && <section className="panel verdict-panel"><p className="eyebrow">AI പരിശോധന പൂർത്തിയായി</p><div className="measure"><strong>99.8</strong><span>% understanding confidence</span></div><h2>എല്ലാം മനസ്സിലായി.</h2><p className="verdict-copy">സഹായമായോ എന്നത് ഈ പരിശോധനയുടെ പരിധിയിൽപ്പെടുന്നില്ല.</p><div className="action-row"><button className="secondary" onClick={retry}>വീണ്ടും <span>↻</span></button><button className="primary" onClick={nextTest}>അടുത്ത പരിശോധന <span>→</span></button></div></section>}
    {phase === 'verdict' && verdict === 'eta_correct' && test === 'eta' && <section className="panel verdict-panel"><p className="eyebrow">ETA പരിശോധന പൂർത്തിയായി</p><div className="measure"><strong>വരും</strong><span>official estimated arrival time</span></div><h2>ഇപ്പോൾ ശരിയായി.</h2><p className="verdict-copy">കൃത്യത കുറച്ചു. ആത്മവിശ്വാസം നിലനിർത്തി.</p><button className="primary" onClick={nextTest}>അവസാന പരിശോധന <span>→</span></button></section>}

    {phase === 'results' && <section className="panel results-panel"><p className="eyebrow">ഡ്രൈവർ അഭിരുചി റിപ്പോർട്ട്</p><h2>{candidateName || 'പരീക്ഷാർത്ഥി'} യോഗ്യത നേടി.</h2><div className="results-grid"><div><span>Passenger Cardio</span><b>{cardio} m</b></div><div><span>Horn Diplomacy</span><b>{hornScore || 92}%</b></div><div><span>AI Understanding</span><b>99.8%</b></div><div><span>ETA Precision</span><b>“വരും”</b></div><div><span>Final Stop Calibration</span><b>{finalOffset ? `${finalOffset >= 0 ? '+' : ''}${finalOffset.toFixed(1)} m` : 'Approved'}</b></div><div><span>അനാവശ്യ ആത്മവിശ്വാസം</span><b>100%</b></div></div><div className="result-stamp">വണ്ടി എടുത്തോളൂ.</div><p className="verdict-copy">ലൈസൻസ് ഉണ്ടോ എന്നത് പ്രത്യേകം പരിശോധിക്കുന്നതാണ്.</p><div className="action-row"><button className="primary" onClick={showCertificate}>സർട്ടിഫിക്കറ്റ് <span>→</span></button><button className="secondary" onClick={begin}>വീണ്ടും പരീക്ഷിക്കാം <span>↻</span></button></div></section>}

    {phase === 'certificate' && <section className="certificate-screen"><div className="certificate-actions no-print"><button className="secondary" onClick={backToResults}>← ഫലത്തിലേക്ക്</button><button className="primary" onClick={() => window.print()}>PDF ആയി സൂക്ഷിക്കാം <span>↓</span></button></div><article className="certificate-paper"><div className="certificate-border"><div className="certificate-mark">അടുത്ത സ്റ്റോപ്പിൽ™</div><p className="certificate-kicker">UNOFFICIAL NATURAL DRIVING APTITUDE AUTHORITY</p><h2>കേരള ബസ് ഡ്രൈവിംഗ്<br />സ്വാഭാവിക അഭിരുചി സർട്ടിഫിക്കറ്റ്</h2><p className="certificate-copy">ഇതുവഴി</p><h3>{candidateName || 'പരീക്ഷാർത്ഥി'}</h3><p className="certificate-copy wide">ആവശ്യത്തിന് കൂടുതലുള്ള ആത്മവിശ്വാസവും ആവശ്യത്തിന് കുറവുള്ള ETA കൃത്യതയും വിജയകരമായി തെളിയിച്ചിരിക്കുന്നതായി സാക്ഷ്യപ്പെടുത്തുന്നു.</p><div className="certificate-metrics"><div><span>Specialisation</span><b>ഹോൺ അധിഷ്ഠിത ഗതാഗത നയതന്ത്രം</b></div><div><span>Rank</span><b>A+ — വണ്ടി എടുത്തോളൂ</b></div></div><div className="certificate-footer"><div><span>Certificate ID</span><b>{certificateId || 'AS-DEMO'}</b></div><button className="verify-button no-print" onClick={() => setVerifyJoke(true)}>VERIFY</button><div className="fake-sign"><i>അംഗീകരിച്ചു</i><span>പരീക്ഷാ അധികാരി</span></div></div>{verifyJoke && <div className="verify-joke no-print">“ഇത് ശരിക്കും verify ചെയ്യാൻ വന്നോ?”</div>}<p className="certificate-note">ഇത് ഒരു parody സർട്ടിഫിക്കറ്റ് മാത്രമാണ്. യഥാർത്ഥ ഡ്രൈവിംഗ് യോഗ്യതയായി ഉപയോഗിക്കരുത്.</p></div></article></section>}

    <div className="portrait-warning"><strong>ഫോൺ ഒന്ന് തിരിക്കൂ.</strong><span>Landscape mode-ലാണ് വണ്ടി എളുപ്പം.</span></div>
  </div>
}
