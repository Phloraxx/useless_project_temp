import { useMemo, useRef } from 'react'
import { useFrame, useLoader } from '@react-three/fiber'
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js'
import * as THREE from 'three'
import { useGameStore } from '../state/gameStore'

const ROAD_W = 12.8
const ROAD_EDGE = ROAD_W / 2
const LANE_X = -3.25
const SHOULDER_X = 7.65

function useSignTexture(text: string, bg = '#ead9a9', fg = '#26302d') {
  return useMemo(() => {
    const canvas = document.createElement('canvas')
    canvas.width = 768; canvas.height = 192
    const ctx = canvas.getContext('2d')!
    ctx.fillStyle = bg; ctx.fillRect(0, 0, canvas.width, canvas.height)
    ctx.fillStyle = fg
    ctx.font = '700 74px "Noto Sans Malayalam", sans-serif'
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle'
    ctx.fillText(text, canvas.width / 2, canvas.height / 2 + 4)
    const texture = new THREE.CanvasTexture(canvas)
    texture.colorSpace = THREE.SRGBColorSpace
    texture.needsUpdate = true
    return texture
  }, [text, bg, fg])
}

function SignBoard({ text, position, width = 2.8, height = .7, bg, fg, rotationY = 0 }: { text: string; position: [number, number, number]; width?: number; height?: number; bg?: string; fg?: string; rotationY?: number }) {
  const texture = useSignTexture(text, bg, fg)
  return <mesh position={position} rotation={[0, rotationY, 0]} castShadow>
    <boxGeometry args={[width, height, .10]} />
    <meshStandardMaterial map={texture} roughness={.9} />
  </mesh>
}

function Person({ x, z, shirt, facing = 0 }: { x: number; z: number; shirt: string; facing?: number }) {
  return <group position={[x, 0, z]} rotation={[0, facing, 0]}>
    <mesh castShadow position={[0,1.58,0]}><dodecahedronGeometry args={[.22,0]}/><meshStandardMaterial color="#76503d" roughness={.95}/></mesh>
    <mesh castShadow position={[0,1.72,-.015]} scale={[1,.46,.92]}><sphereGeometry args={[.23,8,5]}/><meshStandardMaterial color="#28241f" roughness={1}/></mesh>
    <mesh castShadow position={[0,1.05,0]}><cylinderGeometry args={[.20,.28,.72,6]}/><meshStandardMaterial color={shirt} roughness={.95}/></mesh>
    {[-.12,.12].map(xx=><mesh key={xx} castShadow position={[xx,.40,0]}><cylinderGeometry args={[.065,.08,.72,6]}/><meshStandardMaterial color="#3e3934" roughness={1}/></mesh>)}
    <mesh castShadow position={[-.30,1.05,0]} rotation={[0,0,-.24]}><cylinderGeometry args={[.055,.065,.68,6]}/><meshStandardMaterial color="#76503d" roughness={.95}/></mesh>
    <mesh castShadow position={[.30,1.05,0]} rotation={[0,0,.24]}><cylinderGeometry args={[.055,.065,.68,6]}/><meshStandardMaterial color="#76503d" roughness={.95}/></mesh>
  </group>
}

function CoconutTree({ x, z, scale = 1, lean = 0 }: { x: number; z: number; scale?: number; lean?: number }) {
  return <group position={[x,0,z]} scale={scale} rotation={[0,0,lean]}>
    <mesh castShadow position={[0,3.1,0]}><cylinderGeometry args={[.13,.28,6.2,9]} /><meshStandardMaterial color="#725039" roughness={1} /></mesh>
    <group position={[0,6.15,0]}>
      <mesh castShadow><sphereGeometry args={[.46,8,6]} /><meshStandardMaterial color="#29583a" roughness={1} /></mesh>
      {Array.from({length:8},(_,i)=>{
        const a=(i/8)*Math.PI*2
        return <group key={i} rotation={[0,a,0]}>
          <mesh castShadow position={[0,-.04,-.92]} rotation={[-.12,0,0]}>
            <boxGeometry args={[.32,.07,1.9]} /><meshStandardMaterial color={i%2?'#356f46':'#2f653f'} roughness={1} />
          </mesh>
          <mesh castShadow position={[0,-.34,-2.28]} rotation={[-.32,0,0]}>
            <boxGeometry args={[.23,.055,1.25]} /><meshStandardMaterial color={i%2?'#2d613e':'#38754a'} roughness={1} />
          </mesh>
        </group>
      })}
      {[[-.18,-.05],[.14,.08],[.02,-.2]].map(([xx,zz],i)=><mesh key={`c${i}`} castShadow position={[xx,-.42,zz]}><sphereGeometry args={[.17,7,5]} /><meshStandardMaterial color="#5c5a2c" /></mesh>)}
    </group>
  </group>
}


function BananaPlant({x,z,s=1}:{x:number;z:number;s?:number}) {
  return <group position={[x,0,z]} scale={s}>
    <mesh castShadow position={[0,.85,0]}><cylinderGeometry args={[.055,.10,1.7,7]}/><meshStandardMaterial color="#60733d"/></mesh>
    {Array.from({length:6},(_,i)=>{const a=i/6*Math.PI*2;return <group key={i} rotation={[0,a,0]}><mesh castShadow position={[0,1.65,-.78]} rotation={[-.38,0,0]}><boxGeometry args={[.28,.045,1.65]}/><meshStandardMaterial color={i%2?'#4e8248':'#5b914f'} roughness={1}/></mesh></group>})}
  </group>
}

function LowWall({x,z,length=5,rotationY=0}:{x:number;z:number;length?:number;rotationY?:number}) {
  return <group position={[x,0,z]} rotation={[0,rotationY,0]}>
    <mesh castShadow position={[0,.48,0]}><boxGeometry args={[length,.88,.20]}/><meshStandardMaterial color="#c8bea2" roughness={1}/></mesh>
    <mesh castShadow position={[0,.94,0]}><boxGeometry args={[length+.08,.08,.25]}/><meshStandardMaterial color="#7f4b38" roughness={1}/></mesh>
  </group>
}

function Cloud({x,y,z,s=1}:{x:number;y:number;z:number;s?:number}) {
  return <group position={[x,y,z]} scale={s}>
    {[[-1.1,0,0],[0,0,0],[1.0,.05,.1],[-.35,.42,.05],[.55,.32,-.05]].map(([xx,yy,zz],i)=><mesh key={i} position={[xx,yy,zz]}><dodecahedronGeometry args={[.9,0]}/><meshStandardMaterial color={i%2?'#c5cfca':'#d0d8d3'} roughness={1} transparent opacity={.72}/></mesh>)}
  </group>
}

function RoadsideMarker({x,z}:{x:number;z:number}) {
  return <group position={[x,0,z]}>
    <mesh castShadow position={[0,.46,0]}><boxGeometry args={[.18,.92,.18]}/><meshStandardMaterial color="#e8dfc2"/></mesh>
    <mesh position={[0,.72,.095]}><boxGeometry args={[.19,.18,.025]}/><meshBasicMaterial color="#333733"/></mesh>
  </group>
}
function Bush({ x,z,s=1 }: {x:number;z:number;s?:number}) {
  return <group position={[x,.35,z]} scale={s}>
    {[[0,0],[-.45,.12],[.4,.18],[-.12,-.35]].map(([xx,zz],i)=><mesh key={i} castShadow position={[xx,0,zz]}><dodecahedronGeometry args={[.55,0]} /><meshStandardMaterial color={i%2?'#406f45':'#365f3d'} roughness={1} /></mesh>)}
  </group>
}

function UtilityPole({ x,z }: {x:number;z:number}) {
  return <group position={[x,0,z]}>
    <mesh castShadow position={[0,2.9,0]}><cylinderGeometry args={[.09,.13,5.8,8]} /><meshStandardMaterial color="#77776d" roughness={1} /></mesh>
    <mesh castShadow position={[0,5.25,0]}><boxGeometry args={[1.25,.10,.10]} /><meshStandardMaterial color="#555953" /></mesh>
    {[-.45,.45].map(xx=><mesh key={xx} position={[xx,5.12,0]}><cylinderGeometry args={[.08,.08,.18,8]} /><meshStandardMaterial color="#302f2c" /></mesh>)}
  </group>
}

function WireSpan({a,b,offset=0}:{a:[number,number];b:[number,number];offset?:number}) {
  const line=useMemo(()=>{
    const points=Array.from({length:9},(_,i)=>{
      const t=i/8
      const x=THREE.MathUtils.lerp(a[0],b[0],t)+offset
      const z=THREE.MathUtils.lerp(a[1],b[1],t)
      const y=5.12-Math.sin(Math.PI*t)*.42
      return new THREE.Vector3(x,y,z)
    })
    return new THREE.Line(new THREE.BufferGeometry().setFromPoints(points),new THREE.LineBasicMaterial({color:'#30332e',transparent:true,opacity:.72}))
  },[a,b,offset])
  return <primitive object={line}/>
}

function StopShelter({ z = -14 }: { z?: number }) {
  const sign = useSignTexture('അടുത്ത സ്റ്റോപ്പ്', '#efe0b6', '#27312e')
  return <group position={[-8.25,0,z]} rotation={[0,-Math.PI/2,0]}>
    <mesh receiveShadow position={[0,.10,0]}><boxGeometry args={[4.9,.20,2.6]} /><meshStandardMaterial color="#8c633f" /></mesh>
    <mesh castShadow position={[0,1.45,1.17]}><boxGeometry args={[4.7,2.7,.14]} /><meshStandardMaterial color="#d3c7a7" roughness={1} /></mesh>
    {[-2.18,2.18].map(x=><mesh key={x} castShadow position={[x,1.38,-1.05]}><boxGeometry args={[.18,2.75,.18]} /><meshStandardMaterial color="#70695b" /></mesh>)}
    {Array.from({length:8},(_,i)=><mesh key={i} castShadow position={[-2.25+i*.64,2.83,0]} rotation={[0,0,.04]}><boxGeometry args={[.68,.08,2.85]} /><meshStandardMaterial color={i%2?'#9d4035':'#a94839'} roughness={.9} /></mesh>)}
    <mesh position={[0,2.02,1.085]}><planeGeometry args={[3.7,.55]} /><meshStandardMaterial map={sign} roughness={1} /></mesh>
    <mesh castShadow position={[0,.55,.25]}><boxGeometry args={[2.8,.12,.50]} /><meshStandardMaterial color="#6f543d" /></mesh>
    <mesh castShadow position={[0,.30,.25]}><boxGeometry args={[.16,.60,.45]} /><meshStandardMaterial color="#594636" /></mesh>
    <Person x={-1.35} z={-.48} shirt="#d89d43" facing={.2} /><Person x={0} z={-.38} shirt="#4779a8" /><Person x={1.25} z={-.45} shirt="#754c70" facing={-.15} />
    <mesh receiveShadow position={[2.6,.04,0]}><boxGeometry args={[1.25,.08,2.2]} /><meshStandardMaterial color="#aaa38e" /></mesh>
  </group>
}

function TeaShop() {
  return <group position={[9.75,0,-27]} rotation={[0,Math.PI/2,0]}>
    <mesh castShadow position={[0,1.55,0]}><boxGeometry args={[5.6,3.1,4.8]} /><meshStandardMaterial color="#d1b887" roughness={1} /></mesh>
    <mesh position={[-1.1,1.35,-2.43]}><boxGeometry args={[2.7,1.65,.08]} /><meshStandardMaterial color="#342f28" emissive="#73511e" emissiveIntensity={.18} /></mesh>
    <mesh position={[1.55,1.32,-2.44]}><boxGeometry args={[1.45,1.58,.08]} /><meshStandardMaterial color="#5c3e2e" /></mesh>
    {Array.from({length:9},(_,i)=><mesh key={i} castShadow position={[-2.7+i*.68,3.23,0]} rotation={[0,0,-.02]}><boxGeometry args={[.72,.10,5.25]} /><meshStandardMaterial color={i%2?'#8f4935':'#a4543c'} roughness={.9} /></mesh>)}
    <SignBoard text="ചായ • കാപ്പി" position={[0,2.55,-2.55]} width={3.4} height={.58} bg="#355844" fg="#f4dfaa" />
    <mesh castShadow position={[-2.1,.48,-2.9]}><boxGeometry args={[1.8,.12,.55]} /><meshStandardMaterial color="#65462e" /></mesh>
    {[-2.75,-1.45].map(x=><mesh key={x} position={[x,.24,-2.9]}><boxGeometry args={[.10,.48,.48]} /><meshStandardMaterial color="#4b392a" /></mesh>)}
    <mesh position={[2.25,2.0,-2.55]}><boxGeometry args={[1.05,.55,.06]} /><meshStandardMaterial color="#426f8c" roughness={.8} /></mesh>
  </group>
}

function KeralaHouse({ x,z,scale=1,rotationY=0 }: {x:number;z:number;scale?:number;rotationY?:number}) {
  return <group position={[x,0,z]} scale={scale} rotation={[0,rotationY,0]}>
    <mesh castShadow position={[0,1.5,0]}><boxGeometry args={[5.1,3,4.6]} /><meshStandardMaterial color="#e0d2b0" roughness={1} /></mesh>
    <mesh castShadow position={[-1.27,3.1,0]} rotation={[0,0,.38]}><boxGeometry args={[2.9,.18,5.1]} /><meshStandardMaterial color="#8e4433" roughness={.95} /></mesh>
    <mesh castShadow position={[1.27,3.1,0]} rotation={[0,0,-.38]}><boxGeometry args={[2.9,.18,5.1]} /><meshStandardMaterial color="#954938" roughness={.95} /></mesh>
    <mesh position={[0,1.12,-2.33]}><boxGeometry args={[1.05,2.1,.08]} /><meshStandardMaterial color="#5a3f2d" /></mesh>
    {[-1.55,1.55].map(xx=><mesh key={xx} position={[xx,1.55,-2.34]}><boxGeometry args={[1.05,1.05,.06]} /><meshStandardMaterial color="#36535b" roughness={.35} /></mesh>)}
    <mesh castShadow position={[0,.16,-2.75]}><boxGeometry args={[5.5,.22,1.1]} /><meshStandardMaterial color="#a59c87" /></mesh>
  </group>
}

function RoadPatch({x,z,w,l,color='#242827'}:{x:number;z:number;w:number;l:number;color?:string}) {
  return <mesh rotation={[-Math.PI/2,0,0]} position={[x,.018,z]}><planeGeometry args={[w,l]} /><meshBasicMaterial color={color} /></mesh>
}

function AutoRickshawModel() {
  const gltf=useLoader(GLTFLoader,'/models/auto-rickshaw.glb')
  const model=useMemo(()=>{const clone=gltf.scene.clone(true);clone.traverse(o=>{if(o instanceof THREE.Mesh){o.castShadow=true;o.receiveShadow=true}});return clone},[gltf.scene])
  return <primitive object={model}/>
}

function CompactCarModel({color}:{color:string}) {
  const gltf=useLoader(GLTFLoader,'/models/compact-car.glb')
  const model=useMemo(()=>{
    const clone=gltf.scene.clone(true)
    clone.traverse(o=>{
      if(!(o instanceof THREE.Mesh)) return
      o.castShadow=true; o.receiveShadow=true
      const materials=Array.isArray(o.material)?o.material:[o.material]
      const cloned=materials.map(m=>{const c=m.clone(); if(c.name==='BodyColor' && 'color' in c) (c as THREE.MeshStandardMaterial).color.set(color); return c})
      o.material=Array.isArray(o.material)?cloned:cloned[0]
    })
    return clone
  },[gltf.scene,color])
  return <primitive object={model}/>
}

function VehicleBody({ color, kind }: { color: string; kind: 'auto' | 'car' }) {
  return kind==='auto' ? <AutoRickshawModel/> : <CompactCarModel color={color}/>
}

function TrafficVehicle({ z, threshold, color, kind }: { z: number; threshold: number; color: string; kind: 'auto' | 'car' }) {
  const ref=useRef<THREE.Group>(null); const hornCount=useGameStore(s=>s.hornCount)
  useFrame((_,dt)=>{ if(!ref.current)return; const targetX=hornCount>=threshold?2.8:LANE_X; ref.current.position.x=THREE.MathUtils.damp(ref.current.position.x,targetX,4.5,dt); ref.current.rotation.y=THREE.MathUtils.damp(ref.current.rotation.y,hornCount>=threshold?-.18:0,4,dt) })
  return <group ref={ref} position={[LANE_X,kind==='auto'?0:.2,z]}><VehicleBody color={color} kind={kind}/></group>
}

function FinalTraffic(){ const ref=useRef<THREE.Group>(null); const horns=useGameStore(s=>s.finalHornCount); useFrame((_,dt)=>{if(!ref.current)return;ref.current.position.x=THREE.MathUtils.damp(ref.current.position.x,horns>=2?3.4:LANE_X,4,dt);ref.current.rotation.y=THREE.MathUtils.damp(ref.current.rotation.y,horns>=2?-.24:0,4,dt)}); return <group ref={ref} position={[LANE_X,0,5.5]}><VehicleBody color="#d09d23" kind="auto"/></group> }

function Rain(){
  const ref=useRef<THREE.LineSegments>(null)
  const positions=useMemo(()=>{
    const count=340
    const a=new Float32Array(count*6)
    for(let i=0;i<count;i++){
      const x=(Math.random()-.5)*58
      const y=Math.random()*22+1
      const z=(Math.random()-.5)*112-8
      const j=i*6
      a[j]=x; a[j+1]=y; a[j+2]=z
      a[j+3]=x-.06; a[j+4]=y-.45; a[j+5]=z+.04
    }
    return a
  },[])
  useFrame((_,dt)=>{
    if(!ref.current)return
    const arr=ref.current.geometry.attributes.position.array as Float32Array
    for(let i=0;i<arr.length;i+=6){
      arr[i+1]-=17*dt; arr[i+4]-=17*dt
      arr[i]-=1.7*dt; arr[i+3]-=1.7*dt
      if(arr[i+1]<.2){
        const reset=23+Math.random()*3
        const dy=arr[i+1]-arr[i+4]
        arr[i+1]=reset; arr[i+4]=reset-dy
      }
    }
    ref.current.geometry.attributes.position.needsUpdate=true
  })
  return <lineSegments ref={ref} frustumCulled={false}>
    <bufferGeometry><bufferAttribute attach="attributes-position" args={[positions,3]}/></bufferGeometry>
    <lineBasicMaterial color="#dce8e6" transparent opacity={.48} depthWrite={false}/>
  </lineSegments>
}

function FinalRound(){ return <>
  <mesh receiveShadow position={[0,.15,-13]}><cylinderGeometry args={[2.5,2.7,.3,28]}/><meshStandardMaterial color="#6b7657" roughness={1}/></mesh>
  <mesh position={[0,1.1,-13]} castShadow><cylinderGeometry args={[.15,.2,2.2,10]}/><meshStandardMaterial color="#4c5148"/></mesh>
  <mesh position={[0,2.35,-13]} castShadow><sphereGeometry args={[.55,10,8]}/><meshStandardMaterial color="#e3c870" emissive="#66531d" emissiveIntensity={.25}/></mesh>
  <mesh rotation={[-Math.PI/2,0,0]} position={[LANE_X,.035,-28]}><planeGeometry args={[5.6,12]}/><meshBasicMaterial color="#d9b84f" transparent opacity={.22} side={THREE.DoubleSide}/></mesh>
  <StopShelter z={-28}/><FinalTraffic/><Rain/>
</> }

export function World(){
  const test=useGameStore(s=>s.test); const final=test==='final'
  const marks=useMemo(()=>Array.from({length:22},(_,i)=>52-i*7),[])
  const leftPoles=useMemo<[number,number][]>(()=>[[-10.2,-48],[-9.6,-25],[-10.2,-2],[-9.6,21],[-10.2,44]],[])
  const rightPoles=useMemo<[number,number][]>(()=>[[10.5,-39],[9.9,-15],[10.5,10],[9.9,35]],[])
  return <>
    <color attach="background" args={[final?'#667775':'#98aaa4']}/>
    <fog attach="fog" args={[final?'#667775':'#98aaa4',62,125]}/>
    <hemisphereLight intensity={final?.82:1.18} color="#e8efe5" groundColor="#3f5842"/>
    <directionalLight castShadow position={[10,20,12]} intensity={final?1.05:1.65} color="#f8e8c3" shadow-mapSize-width={1024} shadow-mapSize-height={1024} shadow-camera-left={-20} shadow-camera-right={20} shadow-camera-top={20} shadow-camera-bottom={-20}/>

    <mesh receiveShadow rotation={[-Math.PI/2,0,0]} position={[0,-.05,-14]}><planeGeometry args={[100,165]}/><meshStandardMaterial color="#506b48" roughness={1}/></mesh>
    <mesh receiveShadow rotation={[-Math.PI/2,0,0]} position={[0,0,-14]}><planeGeometry args={[ROAD_W,150]}/><meshStandardMaterial color={final?'#252c2d':'#303433'} roughness={final?.72:.96} metalness={final?.04:0}/></mesh>
    <mesh receiveShadow rotation={[-Math.PI/2,0,0]} position={[-SHOULDER_X,.01,-14]}><planeGeometry args={[2.5,150]}/><meshStandardMaterial color="#9b6237" roughness={1}/></mesh>
    <mesh receiveShadow rotation={[-Math.PI/2,0,0]} position={[SHOULDER_X,.01,-14]}><planeGeometry args={[2.5,150]}/><meshStandardMaterial color="#9b6237" roughness={1}/></mesh>
    {[ -8.9,8.9 ].map(x=><mesh key={x} receiveShadow position={[x,-.03,-14]}><boxGeometry args={[.55,.25,150]}/><meshStandardMaterial color="#35423a" roughness={1}/></mesh>)}
    {[-ROAD_EDGE+.30,ROAD_EDGE-.30].map(x=><mesh key={x} rotation={[-Math.PI/2,0,0]} position={[x,.022,-14]}><planeGeometry args={[.10,150]}/><meshBasicMaterial color="#c9c3a9" transparent opacity={.55}/></mesh>)}
    {marks.map(z=><mesh key={z} rotation={[-Math.PI/2,0,0]} position={[0,.025,z]}><planeGeometry args={[.13,3.1]}/><meshBasicMaterial color="#ded8bd"/></mesh>)}
    <RoadPatch x={2.1} z={7} w={2.2} l={4.4}/><RoadPatch x={-1.5} z={-35} w={1.4} l={3.0} color="#3a3d3a"/><RoadPatch x={3.4} z={-8} w={.8} l={2.0} color="#222625"/>

    {test==='stop'&&<mesh rotation={[-Math.PI/2,0,0]} position={[LANE_X,.03,-14]}><planeGeometry args={[5.5,12]}/><meshBasicMaterial color="#d9b84f" transparent opacity={.22} side={THREE.DoubleSide}/></mesh>}
    {!final&&<StopShelter/>}
    <TeaShop/><KeralaHouse x={10.4} z={-4} scale={.92} rotationY={Math.PI/2}/><KeralaHouse x={-12.8} z={18} scale={.78} rotationY={-Math.PI/2}/>

    {leftPoles.map(([x,z])=><UtilityPole key={`l${z}`} x={x} z={z}/>)}
    {rightPoles.map(([x,z])=><UtilityPole key={`r${z}`} x={x} z={z}/>)}
    {leftPoles.slice(0,-1).flatMap((a,i)=>[-.42,0,.42].map(off=><WireSpan key={`lw${i}-${off}`} a={a} b={leftPoles[i+1]} offset={off}/>))}
    {rightPoles.slice(0,-1).flatMap((a,i)=>[-.42,0,.42].map(off=><WireSpan key={`rw${i}-${off}`} a={a} b={rightPoles[i+1]} offset={off}/>))}
    <SignBoard text="തൃശ്ശൂർ" position={[-7.15,2.9,-7.5]} width={2.25} height={.58} bg="#37614c" fg="#f1ddb0" rotationY={Math.PI/2}/>
    {!final&&<><mesh castShadow position={[-6.9,1.45,-11.5]}><cylinderGeometry args={[.055,.07,2.9,8]}/><meshStandardMaterial color="#545851"/></mesh><SignBoard text="സ്റ്റോപ്പ്" position={[-6.9,2.72,-11.5]} width={1.55} height={.46} bg="#355844" fg="#f4dfaa"/></>}

    <CoconutTree x={-13} z={8} lean={-.04}/><CoconutTree x={12.8} z={13} scale={1.08} lean={.035}/><CoconutTree x={-14.5} z={-34} scale={.93} lean={.05}/><CoconutTree x={14.5} z={-43} scale={1.03} lean={-.03}/><CoconutTree x={11.8} z={-20} scale={.82}/>
    <Bush x={-10.6} z={-5} s={1.1}/><Bush x={10.9} z={20} s={.9}/><Bush x={-12} z={-25} s={1.25}/><Bush x={12.5} z={-36} s={.85}/>
    <BananaPlant x={-10.5} z={-12} s={1.05}/><BananaPlant x={11.8} z={-11} s={.9}/><BananaPlant x={-11.6} z={30} s={.8}/><BananaPlant x={12.4} z={-31} s={1.15}/>
    <LowWall x={10.0} z={-8.0} length={5.2} rotationY={Math.PI/2}/><LowWall x={-11.1} z={14.0} length={4.8} rotationY={Math.PI/2}/>
    {!final&&test!=='horn'&&<group position={[8.15,0,-22.5]} rotation={[0,.12,0]} scale={.92}><AutoRickshawModel/></group>}
    {!final&&<group position={[10.5,.18,7.5]} rotation={[0,-Math.PI/2+.08,0]} scale={.86}><CompactCarModel color="#697a83"/></group>}
    {[-44,-20,4,28].map(z=><RoadsideMarker key={`m${z}`} x={-6.05} z={z}/>)}
    <Cloud x={-16} y={13} z={-52} s={1.8}/><Cloud x={17} y={11.5} z={-34} s={1.35}/><Cloud x={-4} y={15} z={-72} s={1.55}/>

    {test==='horn'&&<><TrafficVehicle z={7} threshold={1} color="#d2a21e" kind="auto"/><TrafficVehicle z={-5} threshold={3} color="#4d7f9f" kind="car"/><TrafficVehicle z={-17} threshold={5} color="#a95542" kind="car"/></>}
    {final&&<FinalRound/>}
  </>
}
