import { Canvas } from '@react-three/fiber'
import { Bus } from './Bus'
import { World } from './World'

export function GameCanvas() {
  return <Canvas
    shadows
    dpr={[1, 1.5]}
    camera={{ position: [0, 6, 35], fov: 55, near: 0.1, far: 180 }}
    gl={{ antialias: true, powerPreference: 'high-performance' }}
  >
    <World />
    <Bus />
  </Canvas>
}
