import { useEffect, useMemo, useRef } from 'react'
import { useFrame, useLoader, useThree } from '@react-three/fiber'
import * as THREE from 'three'
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js'
import { useGameStore } from '../state/gameStore'

const START_X = -3.25
const START_Z = 25
const STOP_TARGET_Z = -14
const FINAL_STOP_Z = -28
const HORN_FINISH_Z = -29
const PASSENGER_TRIGGER_Z = 4
const DEBUG_NEAR_STOP = new URLSearchParams(window.location.search).get('near') === '1'
const ACTIVE_START_Z = DEBUG_NEAR_STOP ? -1 : START_Z
const HORN_BLOCKS = [
  { z: 7, threshold: 1 },
  { z: -5, threshold: 3 },
  { z: -17, threshold: 5 },
]

export function Bus() {
  const group = useRef<THREE.Group>(null)
  const gltf = useLoader(GLTFLoader, '/models/hero-bus.glb')
  const model = useMemo(() => {
    const clone = gltf.scene.clone(true)
    clone.traverse((obj) => {
      if ((obj as THREE.Mesh).isMesh) {
        const mesh = obj as THREE.Mesh
        mesh.castShadow = true
        mesh.receiveShadow = true
      }
    })
    return clone
  }, [gltf.scene])
  const routeTexture = useMemo(() => {
    const canvas = document.createElement('canvas')
    canvas.width = 1024; canvas.height = 256
    const ctx = canvas.getContext('2d')!
    ctx.fillStyle = '#10231f'; ctx.fillRect(0, 0, 1024, 256)
    ctx.fillStyle = '#f0c750'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'
    ctx.font = '700 126px "Noto Sans Malayalam", sans-serif'
    ctx.fillText('തൃശ്ശൂർ', 512, 137)
    const texture = new THREE.CanvasTexture(canvas)
    texture.colorSpace = THREE.SRGBColorSpace
    texture.anisotropy = 8
    return texture
  }, [])
  const speed = useRef(0)
  const wheelSpin = useRef(0)
  const yaw = useRef(0)
  const enteredStopZone = useRef(false)
  const hornEvaluated = useRef(false)
  const passengerTriggered = useRef(false)
  const finalTransitioned = useRef(false)
  const { camera, size } = useThree()

  const test = useGameStore((s) => s.test)
  const phase = useGameStore((s) => s.phase)
  const controls = useGameStore((s) => s.controls)
  const hornCount = useGameStore((s) => s.hornCount)
  const passengerStage = useGameStore((s) => s.passengerStage)
  const finalStage = useGameStore((s) => s.finalStage)
  const finalHornCount = useGameStore((s) => s.finalHornCount)
  const resetNonce = useGameStore((s) => s.resetNonce)

  const setSpeed = useGameStore((s) => s.setSpeed)
  const evaluateStop = useGameStore((s) => s.evaluateStop)
  const evaluateHorn = useGameStore((s) => s.evaluateHorn)
  const startPassengerSequence = useGameStore((s) => s.startPassengerSequence)
  const setFinalStage = useGameStore((s) => s.setFinalStage)
  const finishFinalStop = useGameStore((s) => s.finishFinalStop)

  useEffect(() => {
    if (!group.current) return
    group.current.position.set(START_X, 0, ACTIVE_START_Z)
    group.current.rotation.y = 0
    speed.current = 0
    yaw.current = 0
    enteredStopZone.current = false
    hornEvaluated.current = false
    passengerTriggered.current = false
    finalTransitioned.current = false
  }, [resetNonce, test, phase === 'briefing'])

  useEffect(() => {
    const down = (e: KeyboardEvent) => {
      if (e.repeat) return
      const map: Record<string, keyof typeof controls | undefined> = {
        ArrowUp: 'accelerate', w: 'accelerate', W: 'accelerate',
        ArrowDown: 'brake', s: 'brake', S: 'brake',
        ArrowLeft: 'left', a: 'left', A: 'left',
        ArrowRight: 'right', d: 'right', D: 'right',
      }
      const key = map[e.key]
      if (key) useGameStore.getState().setControl(key, true)
      if (e.code === 'Space') { e.preventDefault(); useGameStore.getState().honk() }
    }
    const up = (e: KeyboardEvent) => {
      const map: Record<string, keyof typeof controls | undefined> = {
        ArrowUp: 'accelerate', w: 'accelerate', W: 'accelerate',
        ArrowDown: 'brake', s: 'brake', S: 'brake',
        ArrowLeft: 'left', a: 'left', A: 'left',
        ArrowRight: 'right', d: 'right', D: 'right',
      }
      const key = map[e.key]
      if (key) useGameStore.getState().setControl(key, false)
    }
    window.addEventListener('keydown', down)
    window.addEventListener('keyup', up)
    return () => { window.removeEventListener('keydown', down); window.removeEventListener('keyup', up) }
  }, [controls])

  useFrame((_, dt) => {
    if (!group.current) return
    const bus = group.current

    if (phase === 'driving') {
      const frozenForEta = test === 'eta' || (test === 'final' && (finalStage === 'eta' || finalStage === 'ending'))
      const aiTakeover = test === 'passenger' && passengerStage !== 'idle'
      const accel = 9.5
      const brake = 18

      if (frozenForEta) {
        speed.current = THREE.MathUtils.damp(speed.current, 0, 8, dt)
      } else if (aiTakeover) {
        speed.current = THREE.MathUtils.damp(speed.current, 8.2, 2.6, dt)
        yaw.current = THREE.MathUtils.damp(yaw.current, 0, 4.5, dt)
        bus.position.x = THREE.MathUtils.damp(bus.position.x, START_X, 4.5, dt)
      } else {
        if (controls.accelerate) speed.current += accel * dt
        else speed.current -= Math.sign(speed.current) * Math.min(Math.abs(speed.current), 3 * dt)
        if (controls.brake) {
          if (speed.current > 0) speed.current = Math.max(0, speed.current - brake * dt)
          else speed.current = Math.max(-4, speed.current - 5 * dt)
        }
        speed.current = THREE.MathUtils.clamp(speed.current, -4, 14)
        const steeringScale = THREE.MathUtils.lerp(1, 0.48, Math.min(Math.abs(speed.current) / 14, 1))
        const steer = (Number(controls.left) - Number(controls.right)) * 1.15 * steeringScale
        if (Math.abs(speed.current) > 0.15) yaw.current += steer * dt * Math.sign(speed.current)
      }

      const dir = new THREE.Vector3(Math.sin(yaw.current), 0, -Math.cos(yaw.current))
      if (!frozenForEta) bus.position.addScaledVector(dir, speed.current * dt)
      bus.position.x = THREE.MathUtils.clamp(bus.position.x, -6.4, 6.4)
      bus.rotation.y = yaw.current

      if (test === 'stop') {
        if (bus.position.z < STOP_TARGET_Z + 9) enteredStopZone.current = true
        if (enteredStopZone.current && Math.abs(speed.current) < 0.08) evaluateStop(STOP_TARGET_Z - bus.position.z)
      }

      if (test === 'horn') {
        for (const block of HORN_BLOCKS) {
          const blocked = hornCount < block.threshold
          const inGate = bus.position.z <= block.z + 5.2 && bus.position.z > block.z - 1.5
          if (blocked && inGate && Math.abs(bus.position.x - START_X) < 3) {
            bus.position.z = block.z + 5.2
            speed.current = 0
          }
        }
        if (!hornEvaluated.current && bus.position.z < HORN_FINISH_Z) {
          hornEvaluated.current = true
          speed.current = 0
          evaluateHorn()
        }
      }

      if (test === 'passenger' && !passengerTriggered.current && bus.position.z < PASSENGER_TRIGGER_Z) {
        passengerTriggered.current = true
        startPassengerSequence()
      }

      if (test === 'final') {
        if (finalStage === 'approach' && bus.position.z < 11) setFinalStage('traffic')

        if (finalStage === 'traffic') {
          const inGate = bus.position.z <= 10 && bus.position.z > 3
          if (finalHornCount < 2 && inGate && Math.abs(bus.position.x - START_X) < 3.2) {
            bus.position.z = 10
            speed.current = 0
          }
          if (finalHornCount >= 2 && bus.position.z < 1 && !finalTransitioned.current) {
            finalTransitioned.current = true
            setFinalStage('passenger')
          }
        }

        if (finalStage === 'stop') {
          if (bus.position.z < FINAL_STOP_Z + 9) enteredStopZone.current = true
          if (enteredStopZone.current && Math.abs(speed.current) < 0.08) {
            speed.current = 0
            finishFinalStop(FINAL_STOP_Z - bus.position.z)
          }
        }
      }

      setSpeed(Math.abs(speed.current))
    } else {
      speed.current *= Math.max(0, 1 - dt * 8)
    }

    const chaseDistance = size.width < 900 ? 11.6 : 13.4
    const chaseHeight = size.width < 900 ? 4.35 : 4.75
    const behind = new THREE.Vector3(-Math.sin(yaw.current) * chaseDistance, chaseHeight, Math.cos(yaw.current) * chaseDistance)
    const targetCam = bus.position.clone().add(behind)
    camera.position.lerp(targetCam, 1 - Math.pow(0.002, dt))
    const look = bus.position.clone().add(new THREE.Vector3(Math.sin(yaw.current) * 7.8, 1.65, -Math.cos(yaw.current) * 7.8))
    camera.lookAt(look)

    wheelSpin.current += speed.current * dt / 0.57
    for (const name of ['Wheel_FL', 'Wheel_FR', 'Wheel_RL', 'Wheel_RR']) {
      const wheel = model.getObjectByName(name)
      if (wheel) wheel.rotation.x = wheelSpin.current
    }
  })

  return <group ref={group} position={[START_X, 0, ACTIVE_START_Z]}>
    <primitive object={model} />
    <mesh position={[0, 3.00, -3.705]}>
      <planeGeometry args={[1.92, 0.28]} />
      <meshBasicMaterial map={routeTexture} toneMapped={false} />
    </mesh>
    <mesh position={[0, 3.00, 3.705]} rotation={[0, Math.PI, 0]}>
      <planeGeometry args={[1.48, 0.24]} />
      <meshBasicMaterial map={routeTexture} toneMapped={false} />
    </mesh>
  </group>
}
