import { create } from 'zustand'

export type TestId = 'stop' | 'horn' | 'passenger' | 'eta' | 'final'
export type Phase = 'title' | 'briefing' | 'driving' | 'verdict' | 'results' | 'certificate'
export type StopVerdict = 'too_early' | 'too_precise' | 'acceptable' | 'ideal' | 'too_far'
export type HornVerdict = 'horn_low' | 'horn_good' | 'horn_spam'
export type PassengerVerdict = 'passenger_ai'
export type EtaVerdict = 'eta_correct'
export type Verdict = StopVerdict | HornVerdict | PassengerVerdict | EtaVerdict | null
export type PassengerStage = 'idle' | 'request' | 'scan' | 'recommendation' | 'missed' | 'ack'
export type FinalStage = 'approach' | 'traffic' | 'passenger' | 'eta' | 'stop' | 'ending'

type Controls = { accelerate: boolean; brake: boolean; left: boolean; right: boolean }

type GameState = {
  test: TestId
  phase: Phase
  verdict: Verdict
  stopOffset: number
  finalStopOffset: number
  speed: number
  cardioMeters: number
  hornCount: number
  hornScore: number
  brakePresses: number
  resetNonce: number
  controls: Controls
  passengerStage: PassengerStage
  passengerScan: number
  finalStage: FinalStage
  finalHornCount: number
  candidateName: string
  certificateId: string
  setCandidateName: (name: string) => void
  begin: () => void
  drive: () => void
  retry: () => void
  nextTest: () => void
  jumpTo: (target: TestId | 'results') => void
  setControl: (key: keyof Controls, value: boolean) => void
  setSpeed: (value: number) => void
  honk: () => void
  evaluateStop: (offset: number) => void
  evaluateHorn: () => void
  startPassengerSequence: () => void
  setPassengerStage: (stage: PassengerStage) => void
  setPassengerScan: (value: number) => void
  finishPassenger: () => void
  finishEta: () => void
  setFinalStage: (stage: FinalStage) => void
  finishFinalStop: (offset: number) => void
  finishFinal: () => void
  showCertificate: () => void
  backToResults: () => void
}

const classifyStop = (offset: number): StopVerdict => {
  if (offset < -3) return 'too_early'
  if (offset < 5) return 'too_precise'
  if (offset < 16) return 'acceptable'
  if (offset <= 31) return 'ideal'
  return 'too_far'
}

const hornDiplomacy = (horns: number, brakes: number) => Math.max(0, Math.min(100, 100 - Math.abs(horns - 7) * 12 - brakes * 8))
const classifyHorn = (horns: number, brakes: number): HornVerdict => horns < 5 ? 'horn_low' : horns <= 9 && brakes <= 2 ? 'horn_good' : 'horn_spam'
const emptyControls = (): Controls => ({ accelerate: false, brake: false, left: false, right: false })
const testOrder: TestId[] = ['stop', 'horn', 'passenger', 'eta', 'final']

const resetFor = (target: TestId) => ({
  test: target,
  phase: 'briefing' as Phase,
  verdict: null,
  speed: 0,
  hornCount: 0,
  brakePresses: 0,
  passengerStage: 'idle' as PassengerStage,
  passengerScan: 0,
  finalStage: 'approach' as FinalStage,
  finalHornCount: 0,
  controls: emptyControls(),
})

export const useGameStore = create<GameState>((set, get) => ({
  test: 'stop', phase: 'title', verdict: null,
  stopOffset: 0, finalStopOffset: 0, speed: 0, cardioMeters: 0,
  hornCount: 0, hornScore: 0, brakePresses: 0, resetNonce: 0,
  controls: emptyControls(), passengerStage: 'idle', passengerScan: 0,
  finalStage: 'approach', finalHornCount: 0, candidateName: '', certificateId: '',

  setCandidateName: (name) => set({ candidateName: name.slice(0, 48) }),
  begin: () => set((s) => ({ ...resetFor('stop'), cardioMeters: 0, hornScore: 0, stopOffset: 0, finalStopOffset: 0, candidateName: s.candidateName.trim() || 'പരീക്ഷാർത്ഥി', certificateId: `AS-${Date.now().toString(36).toUpperCase()}` })),
  drive: () => set({ phase: 'driving', verdict: null }),
  retry: () => set((s) => ({
    phase: 'driving', verdict: null, stopOffset: s.test === 'stop' ? 0 : s.stopOffset,
    speed: 0, hornCount: s.test === 'horn' ? 0 : s.hornCount,
    brakePresses: s.test === 'horn' ? 0 : s.brakePresses,
    passengerStage: 'idle', passengerScan: 0,
    finalStage: 'approach', finalHornCount: 0, finalStopOffset: s.test === 'final' ? 0 : s.finalStopOffset,
    resetNonce: s.resetNonce + 1, controls: emptyControls(),
  })),
  nextTest: () => set((s) => {
    const index = testOrder.indexOf(s.test)
    if (index >= testOrder.length - 1) return { phase: 'results', controls: emptyControls() }
    return { ...resetFor(testOrder[index + 1]), resetNonce: s.resetNonce + 1 }
  }),
  jumpTo: (target) => set((s) => {
    if (target === 'results') return {
      phase: 'results', controls: emptyControls(),
      cardioMeters: s.cardioMeters || 84,
      hornScore: s.hornScore || 92,
      finalStopOffset: s.finalStopOffset || 24.6,
    }
    return { ...resetFor(target), resetNonce: s.resetNonce + 1 }
  }),
  setControl: (key, value) => set((s) => ({
    controls: { ...s.controls, [key]: value },
    brakePresses: key === 'brake' && value && !s.controls.brake && s.test === 'horn' && s.phase === 'driving' ? s.brakePresses + 1 : s.brakePresses,
  })),
  setSpeed: (value) => set({ speed: value }),
  honk: () => set((s) => s.phase !== 'driving' ? {} : s.test === 'final' ? { finalHornCount: s.finalHornCount + 1 } : { hornCount: s.hornCount + 1 }),
  evaluateStop: (offset) => set((s) => ({
    phase: 'verdict', verdict: classifyStop(offset), stopOffset: offset,
    cardioMeters: s.cardioMeters + Math.max(0, Math.round(offset)), controls: emptyControls(),
  })),
  evaluateHorn: () => {
    const s = get()
    set({ phase: 'verdict', verdict: classifyHorn(s.hornCount, s.brakePresses), hornScore: hornDiplomacy(s.hornCount, s.brakePresses), controls: emptyControls() })
  },
  startPassengerSequence: () => set((s) => s.test === 'passenger' && s.phase === 'driving' && s.passengerStage === 'idle' ? { passengerStage: 'request' } : {}),
  setPassengerStage: (stage) => set({ passengerStage: stage }),
  setPassengerScan: (value) => set({ passengerScan: Math.max(0, Math.min(100, value)) }),
  finishPassenger: () => set({ phase: 'verdict', verdict: 'passenger_ai', controls: emptyControls(), speed: 0 }),
  finishEta: () => set({ phase: 'verdict', verdict: 'eta_correct', controls: emptyControls(), speed: 0 }),
  setFinalStage: (stage) => set({ finalStage: stage, controls: stage === 'eta' || stage === 'ending' ? emptyControls() : get().controls }),
  finishFinalStop: (offset) => set((s) => ({
    finalStage: 'ending', finalStopOffset: offset,
    cardioMeters: s.cardioMeters + Math.max(0, Math.round(offset)),
    controls: emptyControls(), speed: 0,
  })),
  finishFinal: () => set({ phase: 'results', controls: emptyControls(), speed: 0 }),
  showCertificate: () => set({ phase: 'certificate', controls: emptyControls(), speed: 0 }),
  backToResults: () => set({ phase: 'results' }),
}))
