import { useEffect } from 'react'
import { GameCanvas } from './game/GameCanvas'
import { Overlay } from './ui/Overlay'
import { useGameStore, type TestId } from './state/gameStore'

const demoTargets = new Set(['stop', 'horn', 'passenger', 'eta', 'final', 'results'])

export default function App() {
  const jumpTo = useGameStore((s) => s.jumpTo)

  useEffect(() => {
    const params = new URLSearchParams(window.location.search)
    const requested = params.get('test')
    if (requested && demoTargets.has(requested)) {
      jumpTo(requested as TestId | 'results')
      const debugHorns = Number(params.get('horns') || 0)
      if (requested === 'horn' && Number.isFinite(debugHorns) && debugHorns > 0) {
        useGameStore.setState({ hornCount: debugHorns })
      }
      if (params.get('play') === '1' && requested !== 'results') useGameStore.getState().drive()
    }

    const shortcut = (event: KeyboardEvent) => {
      if (!event.ctrlKey || !event.shiftKey) return
      const target = ({ Digit1: 'stop', Digit2: 'horn', Digit3: 'passenger', Digit4: 'eta', Digit5: 'final', Digit0: 'results' } as const)[event.code]
      if (target) { event.preventDefault(); jumpTo(target) }
    }
    window.addEventListener('keydown', shortcut)
    return () => window.removeEventListener('keydown', shortcut)
  }, [jumpTo])

  return <main className="app-shell">
    <div className="game-stage"><GameCanvas /></div>
    <Overlay />
  </main>
}
